<?php
require 'config/config.php';
echo "¡Conexión exitosa! Usuario actual: " . DB_USER;
