<?php
header('Content-Type: application/json');
require '../config/config.php'; // Asegúrate de que esta ruta sea correcta

// --- GET: listar usuarios o uno solo ---
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['id'])) {
        // Obtener usuario específico
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$_GET['id']]);
        echo json_encode($stmt->fetch(PDO::FETCH_ASSOC));
    } else {
        // Listar todos
        $stmt = $pdo->query("SELECT id, dni, apellidos, nombres, email, celular, role FROM users ORDER BY id DESC");
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    }
    exit;
}

// --- POST: guardar o actualizar ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? '';
    $dni = $_POST['dni'] ?? '';
    $password = $_POST['password'] ?? '';
    $apellidos = $_POST['apellidos'] ?? '';
    $nombres = $_POST['nombres'] ?? '';
    $email = $_POST['email'] ?? '';
    $celular = $_POST['celular'] ?? '';
    $role = $_POST['role'] ?? 'egresado';

    // Validación mínima
    if (!$dni || !$apellidos || !$nombres || !$email) {
        echo json_encode(['success' => false, 'message' => 'Faltan campos obligatorios.']);
        exit;
    }

    try {
        if ($id) {
            // --- UPDATE ---
            if ($password) {
                $hashed = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("UPDATE users SET dni=?, password=?, apellidos=?, nombres=?, email=?, celular=?, role=? WHERE id=?");
                $stmt->execute([$dni, $hashed, $apellidos, $nombres, $email, $celular, $role, $id]);
            } else {
                $stmt = $pdo->prepare("UPDATE users SET dni=?, apellidos=?, nombres=?, email=?, celular=?, role=? WHERE id=?");
                $stmt->execute([$dni, $apellidos, $nombres, $email, $celular, $role, $id]);
            }
        } else {
            // --- INSERT ---
            if (!$password) {
                echo json_encode(['success' => false, 'message' => 'La contraseña es requerida para nuevos usuarios.']);
                exit;
            }

            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (dni, password, apellidos, nombres, email, celular, role) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$dni, $hashed, $apellidos, $nombres, $email, $celular, $role]);
        }

        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }

    exit;
}

// --- DELETE ---
if ($_SERVER['REQUEST_METHOD'] === 'DELETE' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    echo json_encode(['success' => true]);
    exit;
}

// Si llega aquí, método no permitido
http_response_code(405);
echo json_encode(['success' => false, 'message' => 'Método no permitido.']);
