<?php
require '../config/config.php';

$id = $_POST['id'] ?? null;
$dni = $_POST['dni'];
$password = $_POST['password'] ?? null;
$apellidos = $_POST['apellidos'];
$nombres = $_POST['nombres'];
$email = $_POST['email'];
$celular = $_POST['celular'];
$role = $_POST['role'];

// Si se proporciona ID, actualizar
if ($id) {
  if ($password) {
    $hashed = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("UPDATE users SET dni=?, password=?, apellidos=?, nombres=?, email=?, celular=?, role=? WHERE id=?");
    $stmt->execute([$dni, $hashed, $apellidos, $nombres, $email, $celular, $role, $id]);
  } else {
    $stmt = $pdo->prepare("UPDATE users SET dni=?, apellidos=?, nombres=?, email=?, celular=?, role=? WHERE id=?");
    $stmt->execute([$dni, $apellidos, $nombres, $email, $celular, $role, $id]);
  }
} else {
  $hashed = password_hash($password, PASSWORD_DEFAULT);
  $stmt = $pdo->prepare("INSERT INTO users (dni, password, apellidos, nombres, email, celular, role) VALUES (?, ?, ?, ?, ?, ?, ?)");
  $stmt->execute([$dni, $hashed, $apellidos, $nombres, $email, $celular, $role]);
}
