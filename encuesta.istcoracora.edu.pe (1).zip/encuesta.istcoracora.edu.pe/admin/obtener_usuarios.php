<?php
require '../config/config.php';

header('Content-Type: application/json');

$stmt = $pdo->query("SELECT id, dni, nombres, apellidos, email, celular, programa_estudios, anio_egreso, role FROM users ORDER BY id DESC");
$usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($usuarios);
?>
