<?php
require '../config/config.php';
header('Content-Type: application/json; charset=utf-8');

// Si solo se solicitan los filtros
if (isset($_GET['accion']) && $_GET['accion'] === 'filtros') {
    $stmtProg = $pdo->query("SELECT DISTINCT programa_estudios FROM users WHERE role = 'egresado' ORDER BY programa_estudios");
    $stmtAnio = $pdo->query("SELECT DISTINCT anio_egreso FROM users WHERE role = 'egresado' ORDER BY anio_egreso DESC");

    $programas = $stmtProg->fetchAll(PDO::FETCH_COLUMN);
    $anios = $stmtAnio->fetchAll(PDO::FETCH_COLUMN);

    echo json_encode(['programas' => $programas, 'anios' => $anios]);
    exit;
}

// Datos de encuestas
$programa = $_GET['programa'] ?? '';
$anio = $_GET['anio'] ?? '';

$sql = "SELECT 
    trabaja,
    tipo_empresa,
    rubro,
    area_corresponde,
    formacion_adecuada,
    satisfecho,
    autoeval_trabajo,
    comparacion_otros,
    porcentaje_aplicado
FROM encuestas e
JOIN users u ON u.id = e.user_id
WHERE u.role = 'egresado'";

$params = [];

if ($programa !== '') {
    $sql .= " AND u.programa_estudios = ?";
    $params[] = $programa;
}
if ($anio !== '') {
    $sql .= " AND u.anio_egreso = ?";
    $params[] = $anio;
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Funciones
function contarPorCampo($data, $campo) {
    $conteo = [];
    foreach ($data as $fila) {
        $valor = trim($fila[$campo] ?? '');
        $valor = $valor === '' ? 'No responde' : $valor;
        $conteo[$valor] = ($conteo[$valor] ?? 0) + 1;
    }
    return $conteo;
}

function contarEscalaOrdenada($data, $campo) {
    $conteo = ['1'=>0,'2'=>0,'3'=>0,'4'=>0,'5'=>0];
    foreach ($data as $fila) {
        $valor = trim($fila[$campo] ?? '');
        if (!in_array($valor, ['1','2','3','4','5'])) {
            $valor = 'No responde';
        }
        $conteo[$valor] = ($conteo[$valor] ?? 0) + 1;
    }
    return $conteo;
}

function contarPorcentaje($data, $campo) {
    $conteo = [];
    foreach ($data as $fila) {
        $valor = trim($fila[$campo] ?? '');
        if (strpos($valor, '%') !== false) {
            $valor = str_replace('%', '', $valor);
        }
        if ($valor === '' || !is_numeric($valor)) {
            $valor = 'No responde';
        }
        $conteo[$valor] = ($conteo[$valor] ?? 0) + 1;
    }
    ksort($conteo, SORT_NUMERIC);
    return $conteo;
}

// Resultado
$resultado = [
    'trabaja'             => contarPorCampo($data, 'trabaja'),
    'tipo_empresa'        => contarPorCampo($data, 'tipo_empresa'),
    'rubro'               => contarPorCampo($data, 'rubro'),
    'area_corresponde'    => contarPorCampo($data, 'area_corresponde'),
    'formacion_adecuada'  => contarPorCampo($data, 'formacion_adecuada'),
    'satisfecho'          => contarPorCampo($data, 'satisfecho'),
    'autoeval_trabajo'    => contarEscalaOrdenada($data, 'autoeval_trabajo'),
    'comparacion_otros'   => contarEscalaOrdenada($data, 'comparacion_otros'),
    'porcentaje_aplicado' => contarPorcentaje($data, 'porcentaje_aplicado'),
];

echo json_encode($resultado);
exit;
