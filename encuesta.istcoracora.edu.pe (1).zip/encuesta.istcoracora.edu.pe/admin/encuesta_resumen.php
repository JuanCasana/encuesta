<?php

require '../config/config.php';
ini_set('display_errors', 1);
error_reporting(E_ALL);

$accion = $_GET['accion'] ?? '';

if ($accion === 'filtros') {
  $stmt = $pdo->query("SELECT DISTINCT programa_estudios FROM users WHERE role = 'egresado'");
  $programas = $stmt->fetchAll(PDO::FETCH_COLUMN);

  $stmt2 = $pdo->query("SELECT DISTINCT anio_egreso FROM users WHERE role = 'egresado' ORDER BY anio_egreso DESC");
  $anios = $stmt2->fetchAll(PDO::FETCH_COLUMN);

  echo json_encode(['programas' => $programas, 'anios' => $anios]);
  exit;
}

if ($accion === 'filtrar') {
  $programa = $_GET['programa'] ?? '';
  $anio = $_GET['anio'] ?? '';

  $sql = "SELECT u.*, 
                 EXISTS(SELECT 1 FROM encuestas e WHERE e.user_id = u.id) AS encuesta_respondida 
          FROM users u 
          WHERE u.role = 'egresado'";
  $params = [];

  if ($programa !== '') {
    $sql .= " AND u.programa_estudios = ?";
    $params[] = $programa;
  }

  if ($anio !== '') {
    $sql .= " AND u.anio_egreso = ?";
    $params[] = $anio;
  }

  $stmt = $pdo->prepare($sql);
  $stmt->execute($params);
  $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

  $respondidas = 0;
  foreach ($data as &$d) {
    $d['encuesta_respondida'] = (bool)$d['encuesta_respondida'];
    if ($d['encuesta_respondida']) $respondidas++;
  }

  echo json_encode([
    'lista' => $data,
    'total' => count($data),
    'respondidas' => $respondidas
  ]);
  exit;
}

if ($accion === 'descargar_csv') {
  $programa = $_GET['programa'] ?? '';
  $anio = $_GET['anio'] ?? '';

  $sql = "SELECT u.dni, u.nombres, u.apellidos, u.email, u.programa_estudios, u.anio_egreso,
                 EXISTS(SELECT 1 FROM encuestas e WHERE e.user_id = u.id) AS encuesta_respondida 
          FROM users u 
          WHERE u.role = 'egresado'";
  $params = [];

  if ($programa !== '') {
    $sql .= " AND u.programa_estudios = ?";
    $params[] = $programa;
  }

  if ($anio !== '') {
    $sql .= " AND u.anio_egreso = ?";
    $params[] = $anio;
  }

  $stmt = $pdo->prepare($sql);
  $stmt->execute($params);
  $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

  header('Content-Type: text/csv; charset=utf-8');
  header('Content-Disposition: attachment; filename="reporte_encuestas.csv"');

  $out = fopen('php://output', 'w');
  fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF));
  fputcsv($out, ['DNI', 'Nombres', 'Apellidos', 'Email', 'Programa', 'Año Egreso', 'Respondió Encuesta']);

  foreach ($usuarios as $u) {
    fputcsv($out, [
      $u['dni'], $u['nombres'], $u['apellidos'], $u['email'],
      $u['programa_estudios'], $u['anio_egreso'],
      $u['encuesta_respondida'] ? 'Sí' : 'No'
    ]);
  }
  fclose($out);
  exit;
}

if ($accion === 'descargar_pdf') {
  require_once '../vendor/autoload.php'; // asegúrate que TCPDF esté instalado con Composer

  $programa = $_GET['programa'] ?? '';
  $anio = $_GET['anio'] ?? '';

  $sql = "SELECT u.dni, u.nombres, u.apellidos, u.email, u.programa_estudios, u.anio_egreso,
                 EXISTS(SELECT 1 FROM encuestas e WHERE e.user_id = u.id) AS encuesta_respondida 
          FROM users u 
          WHERE u.role = 'egresado'";
  $params = [];

  if ($programa !== '') {
    $sql .= " AND u.programa_estudios = ?";
    $params[] = $programa;
  }

  if ($anio !== '') {
    $sql .= " AND u.anio_egreso = ?";
    $params[] = $anio;
  }

  $stmt = $pdo->prepare($sql);
  $stmt->execute($params);
  $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

  $pdf = new \TCPDF();
  $pdf->SetCreator('IEST Púb "CAGM"');
  $pdf->SetAuthor('Sistema Encuestas');
  $pdf->SetTitle('Reporte de Encuestas');
  $pdf->AddPage();

$programaTexto = $programa ?: 'Todos';
$anioTexto = $anio ?: 'Todos';
$fechaHoy = date('d/m/Y');

    $html = '
    <style>
      .titulo-tabla {
        width: 100%;
        margin-bottom: 10px;
        border: none;
      }
      .titulo-tabla td {
        vertical-align: top;
        border: none;
      }
      .logo {
        width: 100px;
      }
      .titulo-institucion {
        font-size: 14px;
        padding-left: 10px;
        line-height: 1.4;
        color: #000;
        text-align: center;
      }
      .info-filtros {
        font-size: 11px;
        margin-bottom: 10px;
      }
      table {
        border-collapse: collapse;
        width: 100%;
        font-size: 10px;
      }
      th {
        background-color: #043b71;
        color: white;
        font-weight: bold;
      }
      th, td {
        border: 1px solid #ccc;
        padding: 5px;
        text-align: left;
      }
    </style>
    
    <table class="titulo-tabla">
      <tr>
        <td class="logo">
          <img src="' . __DIR__ . '/logo-cesar.png" width="60">
        </td>
        <td class="titulo-institucion">
          <strong>Instituto de Educación Superior Tecnológico Público</strong><br>
          <strong>“César Augusto Guardía Mayorga”</strong><br>
          <strong>Reporte de Encuestas a Egresados</strong>
        </td>
      </tr>
    </table>
    
    <div class="info-filtros">
      <strong>Fecha:</strong> ' . $fechaHoy . '<br>
      <strong>Programa:</strong> ' . $programaTexto . '<br>
      <strong>Año de egreso:</strong> ' . $anioTexto . '
    </div>
     <br></br>
    <table border="1" cellpadding="5">
      <thead>
        <tr>
          <th>DNI</th>
          <th>Nombre</th>
          <th>Email</th>
          <th>Programa</th>
          <th>Año</th>
          <th>Respondió</th>
        </tr>
      </thead>
      <tbody>';


  foreach ($usuarios as $u) {
    $html .= '<tr>
                <td>' . $u['dni'] . '</td>
                <td>' . $u['nombres'] . ' ' . $u['apellidos'] . '</td>
                <td>' . $u['email'] . '</td>
                <td>' . $u['programa_estudios'] . '</td>
                <td>' . $u['anio_egreso'] . '</td>
                <td>' . ($u['encuesta_respondida'] ? 'Sí' : 'No') . '</td>
              </tr>';
  }

  $html .= '</tbody></table>';

  $pdf->writeHTML($html, true, false, true, false, '');
  $pdf->Output('reporte_encuestas.pdf', 'D');
  exit;
}

echo json_encode(['error' => 'Acción no válida']);

