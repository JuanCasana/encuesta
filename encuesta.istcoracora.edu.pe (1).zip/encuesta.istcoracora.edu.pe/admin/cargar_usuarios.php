<?php
require '../config/config.php';
header('Content-Type: application/json');

if (!isset($_FILES['archivo'])) {
  echo json_encode(['success' => false, 'error' => 'Archivo no recibido']);
  exit;
}

$archivo = $_FILES['archivo']['tmp_name'];
if (($handle = fopen($archivo, 'r')) === false) {
  echo json_encode(['success' => false, 'error' => 'No se pudo leer el archivo']);
  exit;
}

$importados = 0;
$errores = [];
$linea = 0;

while (($data = fgetcsv($handle, 1000, ",")) !== false) {
  $linea++;

  if ($linea === 1) continue; // Saltar encabezado

  // Validar número de columnas
  if (count($data) < 7) {
    $errores[] = "Línea $linea: Faltan columnas.";
    continue;
  }

  list($dni, $password, $apellidos, $nombres, $email, $celular, $role) = array_map('trim', $data);

  // Validaciones básicas
  if (!$dni || !$password || !$apellidos || !$nombres || !$email || !$role) {
    $errores[] = "Línea $linea: Uno o más campos requeridos están vacíos.";
    continue;
  }

  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errores[] = "Línea $linea: Email inválido.";
    continue;
  }

  if (!in_array($role, ['egresado', 'admin'])) {
    $errores[] = "Línea $linea: Rol inválido ($role).";
    continue;
  }

  // Validar que no exista por DNI o Email
  $stmt = $pdo->prepare("SELECT id FROM users WHERE dni = ? OR email = ?");
  $stmt->execute([$dni, $email]);
  if ($stmt->fetch()) {
    $errores[] = "Línea $linea: Usuario con DNI o Email ya registrado.";
    continue;
  }

  // Registrar usuario
  $hashed = password_hash($password, PASSWORD_DEFAULT);
  $insert = $pdo->prepare("INSERT INTO users (dni, password, apellidos, nombres, email, celular, role) VALUES (?, ?, ?, ?, ?, ?, ?)");
  $insert->execute([$dni, $hashed, $apellidos, $nombres, $email, $celular, $role]);

  $importados++;
}

fclose($handle);

// Resultado
if ($importados > 0) {
  echo json_encode(['success' => true, 'importados' => $importados, 'errores' => $errores]);
} else {
  echo json_encode(['success' => false, 'importados' => 0, 'errores' => $errores]);
}
