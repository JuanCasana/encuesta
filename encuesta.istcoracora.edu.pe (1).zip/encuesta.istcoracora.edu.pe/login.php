<?php
require 'config/config.php';

session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $dni = $_POST['dni'] ?? '';
  $password = $_POST['password'] ?? '';

  // Buscar usuario por DNI
  $stmt = $pdo->prepare('SELECT * FROM users WHERE dni = ? LIMIT 1');
  $stmt->execute([$dni]);
  $user = $stmt->fetch(PDO::FETCH_ASSOC);

  if ($user && password_verify($password, $user['password'])) {
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['role'] = $user['role'];

    // SOLO PARA EGRESADOS
    if ($user['role'] === 'egresado') {
      // Verificar si ya respondi�� encuesta
      $check = $pdo->prepare("SELECT id FROM encuestas WHERE user_id = ?");
      $check->execute([$user['id']]);

      if ($check->rowCount() > 0) {
        // Ya respondi�� �� ir a gracias.html
        header('Location: actualizar.php');
        exit;
      } else {
        // A��n no responde �� ir a actualizar.php
        header('Location: actualizar.php');
        exit;
      }
    } else {
      // Si es admin u otro rol
      header('Location: admin/panel_admin.html');
      exit;
    }
  } else {
    // Credenciales incorrectas
    header('Location: login.html?error=1');
    exit;
  }
}
?>
